window.addEventListener('DOMContentLoaded', () => {
  const tars = document.createElement('div');
  tars.id = 'mini-tars';
  tars.textContent = '🤖 Mini-TARS: Need help?';
  document.body.appendChild(tars);
});